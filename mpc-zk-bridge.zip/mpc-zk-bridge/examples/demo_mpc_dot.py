from mpc.protocols import dot_product
print("dot([1,2,3],[4,5,6]) =", dot_product([1,2,3],[4,5,6]))