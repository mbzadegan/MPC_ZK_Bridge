# MPC–ZK Bridge: Minimal, Teachable Prototypes in Python

**Goal:** A research-oriented, hands-on repository that bridges the theory and practice of **Secure Multi-Party Computation (MPC)** and **Zero-Knowledge (ZK)**. It contains clean, well-commented Python reference implementations you can extend in a PhD program focused on MPC and ZK. The code is small enough to read in a sitting, but structured to add new protocols and proofs.

> Highlights
> - 2PC additive-sharing over a prime field with Beaver-style secure multiplication (semi-honest).
> - A minimal Pedersen commitment + Schnorr proof of knowledge (Sigma protocol, Fiat–Shamir).
> - A lightweight **MPC-in-the-Head** (MiH) ZK proof for a dot-product relation.
> - Design docs and a roadmap toward post-quantum and efficiency extensions.
> - Pure Python, no dependencies, easy to run and diff in review.

## Quick start
```bash
python3 -m venv .venv && source .venv/bin/activate
# (pure stdlib repo; requirements.txt is empty for portability)
python examples/demo_mpc_dot.py
python examples/demo_zk_schnorr.py
python examples/demo_mih_dot.py
```

You can run `python -m mpc.protocols --help` and `python -m zk.sigma --help` for simple CLIs.

## Repository layout
```
mpc-zk-bridge/
├── mpc/
│   ├── field.py                # finite field utils (safe 61-bit prime by default)
│   ├── sharing.py              # additive secret sharing (2PC) over F_p
│   ├── beaver.py               # toy Beaver triples & secure multiplication
│   ├── protocols.py            # dot product over secret shares; small CLI
│   └── __init__.py
├── zk/
│   ├── pedersen.py             # commitment over multiplicative group mod p
│   ├── sigma.py                # Schnorr PoK (Sigma) + Fiat–Shamir transform
│   ├── mih.py                  # MPC-in-the-Head ZK for dot-product relation
│   └── __init__.py
├── examples/
│   ├── demo_mpc_dot.py         # run a private dot-product via 2PC
│   ├── demo_zk_schnorr.py      # prove knowledge of discrete log
│   └── demo_mih_dot.py         # MiH proof that <x,w>=y without revealing x
├── docs/
│   ├── DESIGN.md               # security model, correctness, soundness notes
│   └── ROADMAP.md              # PQ security, efficiency, extensions
├── LICENSE
├── requirements.txt
└── README.md
```

## Security scope
This code targets educational clarity. It's semi-honest, no network adversaries, tiny primes, and toy PRG seeding for Beaver triples. It’s perfect for explaining ideas and running unit tests—but **not** production. See `docs/ROADMAP.md` for steps toward active security, larger fields, UC-style proofs, and post-quantum options.

## How this aligns with a PhD focus
- **Foundations:** formalize security of each building block, write proofs for privacy/correctness/soundness.
- **Practice:** add micro-benchmarks, constant-factor improvements, and explore communication vs. computation tradeoffs.
- **Post-quantum:** swap discrete-log groups with lattice-/hash-based commitments; plug in MiH with PQ-friendly components; analyze sizes and timings.

## License
MIT
